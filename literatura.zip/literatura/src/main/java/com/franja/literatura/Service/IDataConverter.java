package com.franja.literatura.Service;

public interface IDataConverter { <T> T obtainData(String json, Class<T> anyClass); }
